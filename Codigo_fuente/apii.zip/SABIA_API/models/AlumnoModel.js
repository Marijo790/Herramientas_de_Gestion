const pool = require('../config/db');

class Alumno {

    static async create(data) {

        const {
            nombre,
            apellido_paterno,
            apellido_materno,
            edad,
            nivel_alfabetizacion,
            id_docente
        } = data;

        const result = await pool.query(
            `INSERT INTO alumnos
            (
                nombre,
                apellido_paterno,
                apellido_materno,
                edad,
                nivel_alfabetizacion,
                id_docente
            )
            VALUES($1,$2,$3,$4,$5,$6)
            RETURNING *`,
            [
                nombre,
                apellido_paterno,
                apellido_materno,
                edad,
                nivel_alfabetizacion,
                id_docente
            ]
        );

        return result.rows[0];

        

    }
    static async findByDocente(id_docente) {
    const result = await pool.query(
        'SELECT * FROM alumnos WHERE id_docente = $1 ORDER BY id_alumno ASC',
        [id_docente]
    );

    return result.rows;
}

static async delete(id) {

    const result = await pool.query(
        'DELETE FROM alumnos WHERE id_alumno = $1 RETURNING *',
        [id]
    );

    return result.rows[0];
}

}


module.exports = Alumno;