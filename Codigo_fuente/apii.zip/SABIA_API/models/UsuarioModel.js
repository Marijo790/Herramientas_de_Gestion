const pool = require('../config/db');

class Usuario {

    static async findByCorreo(correo) {

        const result = await pool.query(
            'SELECT * FROM usuarios WHERE correo = $1',
            [correo]
        );

        return result.rows[0];
    }

}

module.exports = Usuario;