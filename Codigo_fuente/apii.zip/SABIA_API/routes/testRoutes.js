const express = require('express');
const authenticate = require('../middlewares/auth');

const router = express.Router();

router.get('/perfil', authenticate, (req, res) => {

    res.json({
        message: 'Ruta protegida funcionando',
        usuario: req.usuario
    });

});

module.exports = router;