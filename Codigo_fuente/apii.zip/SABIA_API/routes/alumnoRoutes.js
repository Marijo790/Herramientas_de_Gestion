const express = require('express');

const AlumnoController = require('../controllers/AlumnoController');

const authenticate = require('../middlewares/auth');

const router = express.Router();

router.post(
    '/alumnos',
    authenticate,
    AlumnoController.createAlumno

);

router.get(
    '/alumnos',
    authenticate,
    AlumnoController.getAlumnos
);
router.delete(
    '/alumnos/:id',
    authenticate,
    AlumnoController.deleteAlumno
);

module.exports = router;