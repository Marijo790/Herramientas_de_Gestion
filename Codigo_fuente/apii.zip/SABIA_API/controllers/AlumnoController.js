const Alumno = require('../models/AlumnoModel');

class AlumnoController {

    static async createAlumno(req, res) {

        try {

            const {
                nombre,
                apellido_paterno,
                apellido_materno,
                edad,
                nivel_alfabetizacion
            } = req.body;

            const nuevoAlumno = await Alumno.create({

                nombre,
                apellido_paterno,
                apellido_materno,
                edad,
                nivel_alfabetizacion,

                // docente autenticado
                id_docente: req.usuario.id_usuario

            });

            res.status(201).json({
                message: 'Alumno registrado correctamente',
                alumno: nuevoAlumno
            });

        } catch (error) {

            res.status(500).json({
                error: error.message
            });

        }

    }
    static async getAlumnos(req, res) {
    try {
        const alumnos = await Alumno.findByDocente(
            req.usuario.id_usuario
        );

        res.json({
            message: 'Alumnos encontrados',
            alumnos
        });

    } catch (error) {
        res.status(500).json({
            error: error.message
        });
    }
}


static async deleteAlumno(req, res) {

    try {

        const alumno = await Alumno.delete(
            req.params.id
        );

        if (!alumno) {
            return res.status(404).json({
                message: 'Alumno no encontrado'
            });
        }

        res.json({
            message: 'Alumno eliminado',
            alumno
        });

    } catch (error) {

        res.status(500).json({
            error: error.message
        });

    }

}

}

module.exports = AlumnoController;