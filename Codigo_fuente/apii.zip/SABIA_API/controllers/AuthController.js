const Usuario = require('../models/UsuarioModel');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

class AuthController {

    static async login(req, res) {

        try {

            const { correo, password } = req.body;

            const usuario = await Usuario.findByCorreo(correo);

            if (!usuario) {
                return res.status(404).json({
                    message: 'Usuario no encontrado'
                });
            }

            const passwordValido = await bcrypt.compare(
                password,
                usuario.password
            );

            if (!passwordValido) {
                return res.status(401).json({
                    message: 'Contraseña incorrecta'
                });
            }

            const token = jwt.sign(
                {
                    id_usuario: usuario.id_usuario,
                    rol: usuario.rol
                },
                process.env.JWT_SECRET,
                {
                    expiresIn: '8h'
                }
            );

            res.json({
                message: 'Login exitoso',
                token,
                usuario: {
                    id_usuario: usuario.id_usuario,
                    nombre: usuario.nombre,
                    correo: usuario.correo,
                    rol: usuario.rol
                }
            });

        } catch (error) {

            res.status(500).json({
                error: error.message
            });

        }

    }

}

module.exports = AuthController;